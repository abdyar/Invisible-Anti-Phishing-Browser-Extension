// Anti-phishing content script test
console.log("Content script loaded");
