chrome.runtime.onInstalled.addListener(() => {
  console.log("Invisible Anti-Phishing Shield is running.");
});
